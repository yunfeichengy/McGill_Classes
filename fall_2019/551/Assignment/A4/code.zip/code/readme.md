We submitted four .ipynb files and three .sh files by which you can replicate our ablation studies. Please checkout https://github.com/ShannonAI/glyce. This github also has instructions and necessary folders to download (fonts and their pretrained chinese bert model). While reproducing our results, please change the path of the home directory, bert_glyce_tagger.py, fonts, and the pretrained bert model in configs, utils, and bin. 
* NER.ipynb
* .sh
* CWS.ipynb
* CWS.sh
* POS_ablation.ipynb
* POS_ablation.sh
* janomeDataProcess.ipynb
Japanese books can be downloaded from https://www.aozora.gr.jp/. Simply unzip and extract the text file. Run janomeDataProcess notebook to process and obtain train, dev, and test files for POS tagging.

We also provide the url to our comet.ml.
https://www.comet.ml/yunfeichengy/551cws/view/
https://www.comet.ml/furiosah/ 
