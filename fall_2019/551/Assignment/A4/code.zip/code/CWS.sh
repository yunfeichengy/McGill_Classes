#!/usr/bin/env bash 
# -*- coding: utf-8 -*- 




# Author: Xiaoy LI 
# Last update: 2019.03.20 
# First create: 2019.03.23 
# Description:
# 

# /content/drive/My Drive/551A4/glyce/glyce/configs

repo_path="/content/mydrive/551A4/glyce/glyce"

data_sign=ctb6_cws
data_dir="/content/mydrive/551A4/cws/cityu"

config_path="/content/mydrive/551A4/glyce/glyce/configs/pkucws_glyce_bert.json"

bert_model="/content/mydrive/551A4/chinese_L-12_H-768_A-12"

task_name=cws
output_dir="/content/mydrive/551A4/glyce/train_log"
max_seq_len=200
train_batch=16
dev_batch=32
test_batch=32
learning_rate=3e-5
num_train_epochs=20
warmup=-1
local_rank=-1
seed=3310
checkpoint=100
gradient_accumulation_steps=2

CUDA_VISIBLE_DEVICES=0  

# COMET_LOGGING_FILE_LEVEL=debug \
#     COMET_LOGGING_FILE= "/content/mydrive/551A4/comet.log"  \
#     COMET_API_KEY="U2Vxm5zBuQlECYKrSn4NLmE7p" \
    python3 "/content/mydrive/551A4/glyce/glyce/bin/run_bert_glyce_tagger.py" \
--data_sign ${data_sign} \
--config_path ${config_path} \
--data_dir ${data_dir} \
--bert_model ${bert_model} \
--task_name ${task_name} \
--max_seq_length ${max_seq_len} \
--do_train \
--do_eval \
--seed ${seed} \
--train_batch_size ${train_batch} \
--dev_batch_size ${dev_batch} \
--test_batch_size ${test_batch} \
--learning_rate ${learning_rate} \
--num_train_epochs ${num_train_epochs} \
--checkpoint ${checkpoint} \
--warmup_proportion ${warmup} \
--gradient_accumulation_steps ${gradient_accumulation_steps}
