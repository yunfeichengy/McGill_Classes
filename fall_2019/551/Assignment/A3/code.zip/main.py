import math
import numpy as np
import pandas as pd
import time as time
# import pickle
# import csv
# import matplotlib.pyplot as plt
import keras
from keras.layers import Dense, Dropout
from keras.layers import GlobalAveragePooling2D
from keras.optimizers import SGD
from keras.applications.xception import Xception
from keras.callbacks import ModelCheckpoint, LearningRateScheduler
from keras.models import Model

# train_images = pd.read_pickle('train_max_x')
# oneDTrainImg = train_images.reshape(train_images.shape[0], train_images.shape[1], train_images.shape[2], 1)
# X_train = oneDTrainImg.repeat(3,axis=3)
# X_train = X_train / 255
# del train_images
# del oneDTrainImg

test_images = pd.read_pickle('test_max_x')
oneDTestImg = test_images.reshape(test_images.shape[0], test_images.shape[1], test_images.shape[2], 1)
X_test = oneDTestImg.repeat(3,axis=3)
X_test = X_test / 255
del test_images
del oneDTestImg

X_train = np.load('modImg.npy')
print(X_train.shape)

train_y = pd.read_csv('train_real_y.csv')
trainYnp = train_y.T.iloc[-1].to_numpy()
onehotY = keras.utils.to_categorical(trainYnp)

def useXception(X_train, onehotY):
    model_res = Xception(include_top=False, weights=None, input_shape=(128, 128, 3))
    # for layer in model_res.layers:
    #     layer.trainable = False
    x = GlobalAveragePooling2D()(model_res.output)
    x = Dense(4096, activation='relu')(x)
    x = Dropout(0.25)(x)
    x = Dense(2048, activation='relu')(x)
    x = Dropout(0.25)(x)
    x = Dense(1024, activation='relu')(x)
    x = Dropout(0.25)(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.25)(x)
    predictions = Dense(10, activation='softmax')(x)
    model = Model(inputs=model_res.input, outputs=predictions)
    model.summary()

    sgd = SGD(lr=0.1, decay=0, momentum=0.8, nesterov=True)

    def step_decay(epoch):
        initial_lrate = 0.1
        drop = 0.667
        epochs_drop = 1
        if epoch > 8:
            if epoch < 36:
                epochs_drop = math.pow(drop, (epoch - 8))
            elif epoch < 50:
                epochs_drop = math.pow(drop, 27)
            else:
                epochs_drop = math.pow(drop, 27) * math.pow(0.75, (epoch - 50))
        lrate = initial_lrate * epochs_drop
        return lrate

    lrate = LearningRateScheduler(step_decay)

    model.compile(optimizer=sgd, loss='categorical_crossentropy', metrics=['accuracy'])

    # weightPath = 'D:\\Mcgill\\U3 fall\\COMP 551\\p3\\tryXcept\\tmp\\XcepWeights1.{epoch:02d}-{val_loss:.2f}.hdf5'
    # checkpointer = ModelCheckpoint(filepath=weightPath, verbose=1, save_weights_only=True)
    model.fit(X_train, onehotY, epochs=90, batch_size=32, verbose=1, callbacks=[lrate])

    y_output = model.predict(X_test)
    y_output = np.argmax(y_output, axis=1)
    pred = pd.DataFrame(y_output, columns=['Label'])
    fileName = 'D:\\Mcgill\\U3 fall\\COMP 551\\p3\\tryXcept\\result\\Xcept150' + time.strftime("%Y%m%d%H",
                                                                                               time.localtime()) + '.csv'
    pred.to_csv(fileName, index=True, index_label='Id', header=True)

    # plt.plot(history.history['loss'])
    # plt.plot(history.history['val_loss'])
    # plt.title("model loss")
    # plt.ylabel("loss")
    # plt.xlabel("epoch")
    # plt.legend(["train", "test"], loc="upper left")
    # plt.show()

useXception(X_train, onehotY)

# def loadXception(X_test):
#     model_res = Xception(include_top=False, weights=None, input_shape=(128, 128, 3))
#     # for layer in model_res.layers:
#     #     layer.trainable = False
#     x = GlobalAveragePooling2D()(model_res.output)
#     x = Dense(4096, activation='relu')(x)
#     x = Dropout(0.25)(x)
#     x = Dense(2048, activation='relu')(x)
#     x = Dropout(0.25)(x)
#     x = Dense(1024, activation='relu')(x)
#     x = Dropout(0.25)(x)
#     x = Dense(256, activation='relu')(x)
#     x = Dropout(0.25)(x)
#     predictions = Dense(10, activation='softmax')(x)
#     model = Model(inputs=model_res.input, outputs=predictions)
#     model.summary()
#
#     sgd = SGD(lr=0.1, decay=0, momentum=0.8, nesterov=True)
#
#     model.compile(optimizer=sgd, loss='categorical_crossentropy', metrics=['accuracy'])
#     model.load_weights('D:\\Mcgill\\U3 fall\\COMP 551\\p3\\tryXcept\\tmp\\XcepWeights1.50-0.06.hdf5')
#     y_output = model.predict(X_test)
#     y_output = np.argmax(y_output, axis=1)
#     pred = pd.DataFrame(y_output, columns=['Label'])
#     fileName = 'D:\\Mcgill\\U3 fall\\COMP 551\\p3\\tryXcept\\result\\Xcept150' + time.strftime("%Y%m%d%H",
#                                                                                            time.localtime()) + '.csv'
#     pred.to_csv(fileName, index=True, index_label='Id', header=True)

# loadXception(X_test)