main.py is the model achieved the Kaggle score.

a3_Oct26.ipynb contains linear models and edge detection algorithm.
proj3.ipynb contains different CNN models using Keras.
proj3test1.ipynb contains digits bounding using OpenCV2

.py file runs on PyCharm
all .ipynb runs on Google Colab